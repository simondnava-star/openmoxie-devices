"""
Boot the REAL stack — broker + `mqtt/run.py` supervisor — from a test, on free ports.

For tests about the assembled appliance (which voice `config` picked, what the supervisor
logged, what a real robot heard). Free ports only (never 1883/8930), a caller-supplied
scratch data dir, and teardown of only the processes it started.

Not used by the hermetic tier (a broker takes seconds); that tier uses
`helpers_runtime.loopback()`.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
BROKER_CONF = os.path.join(REPO, "sim", "broker", "ci-mosquitto.conf")

#: The supervisor's two readiness lines. `CONNECT_LINE` (CONNACK) means the runtime has
#: CALLED `subscribe()`, which only queues a packet — "we asked". A robot's `/state` in that
#: window hits a broker with no subscription and its QoS-0 config answer is never generated.
#: `SUBSCRIBED_LINE` (SUBACK, from `_on_subscribe`) is the only one to boot a robot on;
#: `start(ready_line=CONNECT_LINE)` lets a test stand in the gap deliberately.
CONNECT_LINE = "[runtime] broker connected"
SUBSCRIBED_LINE = "[runtime] subscriptions acknowledged by the broker"


def free_port() -> int:
    import socket
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]
    finally:
        s.close()


def broker_available() -> bool:
    """A mosquitto we can actually start: the binary, or docker with an image we can run."""
    if shutil.which("mosquitto"):
        return True
    if not shutil.which("docker"):
        return False
    return subprocess.run(["docker", "info"], capture_output=True).returncode == 0


class Broker:
    """An anonymous mosquitto on a free port, as CI/SIL uses: the binary if present, else
    docker `eclipse-mosquitto:2` with the conf mounted UNCHANGED and `host:free → 1883`."""

    def __init__(self, log_dir: str):
        self.port = free_port()
        self.log = os.path.join(log_dir, "broker.log")
        self._proc = None
        self._cid = ""

    def start(self, timeout: float = 15.0) -> "Broker":
        if shutil.which("mosquitto"):
            conf = os.path.join(os.path.dirname(self.log), "mosquitto.conf")
            with open(BROKER_CONF) as fh:
                text = fh.read()
            # the binary listens directly on the host port; the websocket listener is
            # dropped so two concurrent runs cannot collide on 9001
            text = text.replace("listener 1883", f"listener {self.port}")
            text = text.split("# WebSocket listener")[0]
            with open(conf, "w") as fh:
                fh.write(text)
            self._proc = subprocess.Popen(["mosquitto", "-c", conf],
                                          stdout=open(self.log, "wb"),
                                          stderr=subprocess.STDOUT)
        else:
            out = subprocess.run(
                ["docker", "run", "-d", "-p", f"127.0.0.1:{self.port}:1883",
                 "-v", f"{BROKER_CONF}:/mosquitto/config/mosquitto.conf:ro",
                 "eclipse-mosquitto:2"], capture_output=True, text=True)
            if out.returncode:
                raise RuntimeError(f"docker broker failed: {out.stderr.strip()}")
            self._cid = out.stdout.strip()
        self.wait_ready(timeout)
        return self

    def wait_ready(self, timeout: float = 15.0):
        # `time.time()` here measures a DURATION, not a date: the loop is a deadline, and
        # its answer is the same at every hour of every day. Clock-reading, not
        # clock-dependent — see the ledger in `test_clock_dependence.py`.
        import socket
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                socket.create_connection(("127.0.0.1", self.port), 1.0).close()
                return
            except OSError:
                time.sleep(0.2)
        raise RuntimeError(f"broker never listened on :{self.port}")

    def stop(self):
        if self._proc:
            self._proc.terminate()
            try:
                self._proc.wait(5)
            except subprocess.TimeoutExpired:
                self._proc.kill()
            self._proc = None
        if self._cid:
            subprocess.run(["docker", "rm", "-f", self._cid], capture_output=True)
            self._cid = ""


class Supervisor:
    """`mqtt/run.py` in a subprocess — the shipped entry point, so `config.build_app()` /
    `build_synthesizer()` precedence is exercised as an appliance reads its environment."""

    def __init__(self, log_dir: str, *, broker_port: int, data_dir: str, env=None):
        self.status_port = free_port()
        self.log = os.path.join(log_dir, "supervisor.log")
        self.env = dict(os.environ)
        self.env.update(
            PYTHONUNBUFFERED="1",                   # or the log is block-buffered + empty
            MOXIE_MQTT_HOST="127.0.0.1", MOXIE_MQTT_PORT=str(broker_port),
            MOXIE_STATUS_PORT=str(self.status_port),
            MOXIE_ALLOW_UNVERIFIED_BOTS="1",        # throwaway d_<uuid> per run, as in run_smoke.sh
            MOXIE_DATA_DIR=data_dir,
            MOXIE_STT="off",                        # nothing here speaks TO the robot
            # No brain needed, so `echo`: `llm` (the default) exits without
            # MOXIE_LLM_BASE_URL (`config.require_llm_base_url`). Brain tests pass MOXIE_APP.
            MOXIE_APP="echo",
        )
        self.env.update(env or {})
        self._proc = None

    def start(self, timeout: float = 60.0,
              ready_line: str = SUBSCRIBED_LINE) -> "Supervisor":
        """Boot `mqtt/run.py` and block until it can be talked to — the SUBACK line by
        default, since between CONNACK and SUBACK the supervisor is connected and deaf."""
        self._proc = subprocess.Popen([sys.executable, os.path.join(REPO, "mqtt", "run.py")],
                                      cwd=REPO, env=self.env,
                                      stdout=open(self.log, "wb"),
                                      stderr=subprocess.STDOUT)
        self.wait_for(ready_line, timeout)
        return self

    def text(self) -> str:
        try:
            with open(self.log) as fh:
                return fh.read()
        except OSError:
            return ""

    def wait_for(self, needle: str, timeout: float = 30.0) -> str:
        # Deadline, not a date — see `wait_ready` above.
        deadline = time.time() + timeout
        while time.time() < deadline:
            body = self.text()
            if needle in body:
                return body
            if self._proc and self._proc.poll() is not None:
                raise RuntimeError(f"supervisor exited rc={self._proc.returncode}\n{body}")
            time.sleep(0.2)
        raise RuntimeError(f"supervisor never logged {needle!r}\n{self.text()}")

    def line_with(self, needle: str) -> str:
        for line in self.text().splitlines():
            if needle in line:
                return line
        return ""

    def stop(self):
        if self._proc:
            self._proc.terminate()
            try:
                self._proc.wait(5)
            except subprocess.TimeoutExpired:
                self._proc.kill()
            self._proc = None


class Stack:
    """Broker + supervisor together, as a context manager."""

    def __init__(self, log_dir: str, *, env=None, data_dir: str | None = None):
        self.log_dir = str(log_dir)
        os.makedirs(self.log_dir, exist_ok=True)
        self.data_dir = data_dir or os.path.join(self.log_dir, "data")
        os.makedirs(self.data_dir, exist_ok=True)
        self.env = env or {}
        self.broker = None
        self.supervisor = None

    def __enter__(self) -> "Stack":
        self.broker = Broker(self.log_dir).start()
        try:
            self.supervisor = Supervisor(self.log_dir, broker_port=self.broker.port,
                                         data_dir=self.data_dir, env=self.env).start()
        except Exception:
            self.broker.stop()
            raise
        return self

    def __exit__(self, *exc):
        if self.supervisor:
            self.supervisor.stop()
        if self.broker:
            self.broker.stop()
        return False

    @property
    def port(self) -> int:
        return self.broker.port

    def restart_supervisor(self, *, env=None, timeout: float = 60.0) -> "Supervisor":
        """Stop `mqtt/run.py` and start a NEW one on the same broker and `MOXIE_DATA_DIR` — a
        real process restart, the only honest proof that durable state is durable.

        The status port is re-picked (a `TIME_WAIT` socket would silently fail the bind), so
        re-read `status_url` from the returned `Supervisor`. `env` overlays the new
        process's environment; omitted, it inherits the first one's.
        """
        assert self.supervisor is not None, "nothing to restart"
        previous = dict(self.supervisor.env)
        self.supervisor.stop()
        merged = {k: v for k, v in previous.items() if k.startswith("MOXIE_")}
        merged.pop("MOXIE_STATUS_PORT", None)       # re-picked by Supervisor.__init__
        merged.update(env or {})
        self.supervisor = Supervisor(self.log_dir, broker_port=self.broker.port,
                                     data_dir=self.data_dir, env=merged)
        # A second process writing the same log path would truncate the first one's
        # evidence, so the restart gets its own file.
        self.supervisor.log = os.path.join(self.log_dir, "supervisor-restart.log")
        return self.supervisor.start(timeout)
