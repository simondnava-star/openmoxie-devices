"""
URL configuration for openmoxie project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include,path
from debug_toolbar.toolbar import debug_toolbar_urls
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic.base import RedirectView
from hive import views as hive_views

urlpatterns = [
    path('', RedirectView.as_view(url='/hive/', permanent=False), name='root'),
    path('hive/', include("hive.urls")),
    path('admin/vision/', hive_views.vision_admin, name='vision_admin'),
    path('admin/vision/status/', hive_views.vision_admin_status, name='vision_admin_status'),
    path('admin/', admin.site.urls),
] + debug_toolbar_urls()

# for now, we only serve our own static content
if True or settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
